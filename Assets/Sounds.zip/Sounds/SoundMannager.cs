﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundMannager : MonoBehaviour {

    public AudioSource FX;
    public AudioSource Music;

    public static SoundMannager instance = null;

    public float lowPitch = .95f;
    public float highPitch = 1.05f;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else if (instance != this) {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);
    }
        public void PlaySingle(AudioClip clip)
        {
            FX.clip = clip;
            FX.Play();
        }

        public void RandomizeFX(params AudioClip[] clips)
        {
            int random = Random.Range(0, clips.Length);

            float randomPitch = Random.Range(lowPitch, highPitch);

            FX.pitch = randomPitch;

            FX.clip = clips[random];

            FX.Play();
        }

 }


